
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { FaWhatsapp } from 'react-icons/fa';

const Home = () => (
  <div>
    <h1>Home</h1>
    <p>Bem-vindo ao sistema de rastreamento veicular da MG PRIME.</p>
  </div>
);

const Dashboard = () => (
  <div>
    <h1>Dashboard</h1>
    <p>Acompanhe a localização dos seus veículos em tempo real.</p>
  </div>
);

const Payment = () => (
  <div>
    <h1>Pagamento</h1>
    <p>Gerencie seus pagamentos através do Mercado Pago.</p>
  </div>
);

const RegisterTracker = ({ onRegister }) => {
  const [trackerId, setTrackerId] = useState('');

  const handleRegister = () => {
    onRegister(trackerId);
    setTrackerId('');
  };

  return (
    <div>
      <h1>Cadastro de Rastreador</h1>
      <input
        type="text"
        value={trackerId}
        onChange={(e) => setTrackerId(e.target.value)}
        placeholder="Digite o IMEI do rastreador"
      />
      <button onClick={handleRegister}>Cadastrar</button>
    </div>
  );
};

const TrackerPanel = ({ trackers }) => (
  <div>
    <h1>Painel de Rastreadores</h1>
    <ul>
      {trackers.map((tracker, index) => (
        <li key={index}>{tracker}</li>
      ))}
    </ul>
  </div>
);

const SupportButton = () => (
  <a
    href="https://wa.me/5548991805924"
    target="_blank"
    rel="noopener noreferrer"
    className="support-button"
  >
    <FaWhatsapp /> Suporte
  </a>
);

const App = () => {
  const [trackers, setTrackers] = useState([]);

  const handleRegister = (trackerId) => {
    setTrackers([...trackers, trackerId]);
    alert(`Rastreador ${trackerId} cadastrado com sucesso!`);
  };

  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/dashboard">Dashboard</Link></li>
            <li><Link to="/payment">Pagamento</Link></li>
            <li><Link to="/register-tracker">Cadastrar Rastreador</Link></li>
            <li><Link to="/tracker-panel">Painel de Rastreadores</Link></li>
          </ul>
        </nav>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="/register-tracker" element={<RegisterTracker onRegister={handleRegister} />} />
          <Route path="/tracker-panel" element={<TrackerPanel trackers={trackers} />} />
        </Routes>

        <SupportButton />
      </div>
    </Router>
  );
};

export default App;
